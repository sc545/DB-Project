//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// HugCoffe.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDD_HUGCOFFE_FORM               101
#define IDR_MAINFRAME                   128
#define IDR_HugCoffeTYPE                130
#define IDD_DIALOG_LOGIN                310
#define IDD_DIALOG_CUTOMER_INSERT       311
#define IDD_DIALOG_CUSTOMER_INSERT      311
#define IDD_DIALOG_CUTOMER_MODIFY       312
#define IDC_EDIT1                       1000
#define IDC_EDIT_ID                     1000
#define IDC_EDIT2                       1001
#define IDC_EDIT_PASS                   1001
#define IDC_TAB_SELECTION               1004
#define IDC_BUTTON4                     1007
#define IDC_LIST1                       1008
#define IDC_BUTTON5                     1009
#define IDC_BUTTON_INSERT               1009
#define IDC_BUTTON6                     1010
#define IDC_BUTTON_MODIFY               1010
#define IDC_BUTTON7                     1011
#define IDC_BUTTON_DELETE               1011
#define IDC_BUTTON8                     1012
#define IDC_BUTTON_SELECT               1012
#define IDC_LIST                        1014
#define IDC_LIST_ORDER                  1014
#define IDC_LIST_MENU2                  1016
#define IDC_LIST_MENU1                  1017
#define IDC_LIST_CUSTOMER               1018
#define IDC_LIST_GOODS                  1019
#define IDC_LIST_SALES                  1020
#define ID_BUTTON_CUSTOMER_OK           1020
#define IDC_EDIT_CUSTOMER_NAME          1021
#define IDC_EDIT_CUSTOMER_PHONE         1022
#define ID_BUTTON_CUSTOMER_CANCEL       1023

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        313
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
