// HugCoffeFormDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "HugCoffe.h"
#include "HugCoffeFormDlg.h"
#include "afxdialogex.h"


// CHugCoffeFormDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CHugCoffeFormDlg, CDialog)

CHugCoffeFormDlg::CHugCoffeFormDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CHugCoffeFormDlg::IDD, pParent)
{

}

CHugCoffeFormDlg::~CHugCoffeFormDlg()
{
}

void CHugCoffeFormDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CHugCoffeFormDlg, CDialog)
END_MESSAGE_MAP()


// CHugCoffeFormDlg �޽��� ó�����Դϴ�.
